# TODO: replace with your own name. Used in the saved model's filename
# and (separately, in the workflow YAML files) in the CI/CD workflow titles.
YOUR_NAME = "your-name"

MODELS_FOLDER = "session_4/models"
DATASETS_FOLDER = "session_4/datasets"
MODEL_NAME = "class_model"

TARGET_COLUMN = "Exited"

# Identifier columns that carry no predictive signal (a row number, an
# internal customer id, and a surname) -- dropped before training.
COLUMNS_TO_DROP = ["RowNumber", "CustomerId", "Surname"]

# Categorical column with a couple of missing values; filled with the
# mode (most frequent category) before one-hot encoding, since an
# encoder can't handle NaN as its own category cleanly.
MODE_IMPUTE_COLUMNS = ["Geography"]

# Numeric columns with a couple of missing values; filled with the median.
MEDIAN_IMPUTE_COLUMNS = ["Age", "HasCrCard"]

# Gender isn't a yes/no field, so it gets its own explicit mapping
# rather than reusing a generic binary-feature mapper.
GENDER_MAPPING = {"Male": 1, "Female": 0}

# Already-binary numeric columns (0/1) that just need a clean int dtype.
BINARY_NUMERIC_COLUMNS = ["HasCrCard", "IsActiveMember"]

ONE_HOT_ENCODE_COLUMNS = ["Geography"]

MODEL_PARAMS = {
    "max_depth": 6,
    "min_samples_leaf": 20,
    "random_state": 8888,
}
