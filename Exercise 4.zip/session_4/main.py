from src.source import load_data
from src.transform import Transformer, balance_dataset
from src.train import train_model
from src.store import store_model
from metadata import MODEL_NAME, TARGET_COLUMN


def main():
    df = load_data(file_name="Churn_Modelling_train_test.csv")
    df = balance_dataset(df, target_column=TARGET_COLUMN)
    df = Transformer().transform(df)
    model = train_model(df=df, target_column=TARGET_COLUMN)
    store_model(model=model, model_name=MODEL_NAME)


# This allows running this file directly (`python session_4/main.py`)
# without re-running main() if this module is ever imported elsewhere.
if __name__ == "__main__":
    main()
